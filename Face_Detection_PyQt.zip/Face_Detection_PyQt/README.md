
## To Install the Facial Recognition Libraries Dependencies

You will need the following:

```pip install dlib==19.18.0```

```pip install face-recognition```
